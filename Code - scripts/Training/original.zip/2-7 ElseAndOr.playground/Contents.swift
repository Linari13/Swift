import Foundation

// Else, And, Or

var height = 48
var weight = 105

if height >= 50 || weight >= 100 {
    print("YOU CAN GO DOWN THE WATERSLIDE")
} else {
    print("Drink your whole milk and come back another time")
}

var name = "nick"
var age = 30

// Make an if statement to see if the person's name is Nick and age is 30
if name == "Nick" && age == 30 {
    print("That's nick!")
}

