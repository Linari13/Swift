import Foundation

// Arrays

var movies = ["Sandlot","Empror's New Groove","LEGO Movie"]

movies.append("Dark Knight Rises")
movies.insert("Dark Knight Rises", at: 1)

movies.remove(at: 0)
movies.count

// List your top 3 favorite movies in a constant array
let favMovies = ["Sandlot","Empror's New Groove","LEGO Movie"]
