import Foundation

// Math, Doubles, and Floats

print(7 + 4)
print(7 - 4)
print(7 * 4)
print(8.0 / 4.0)

var weight = 185.47618926895127958236435634
var age = 30

age * Int(weight)
Double(age) * weight

let feet = 6
let inches = 4

// Find out how many inches tall you are
// There are 12 inches in a foot

feet * 12 + inches

