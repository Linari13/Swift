import Foundation

// Booleans and If Statements

var height = 48

if height >= 50 {
    print("YOU CAN GO DOWN THE WATERSLIDE")
}


// Pick a number around, then if that number is less than 10, print "This is a single digit number"

let number = 8

if number < 10 {
    print(number)
    print("This is a single digit number")
}
