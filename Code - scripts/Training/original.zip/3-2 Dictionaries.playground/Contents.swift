import Foundation

// Dictionaries

var nicksWords : [String:String] = ["zabang":"when you fianlly get your code right","hooha":"When you've been coding for 3 hours and still can't find out what's wrong"]

nicksWords["hooha"]

var dog = ["Fido":5,"Jane":8,"sean":4]

dog["sean"] = 7
dog.removeValue(forKey: "Jane")

dog

// Create a Dictionary for something around you

var drinks = ["Pepsi":4, "Mountain Dew":3, "Claipis":1]
drinks["Mountain Dew"] = 2

