import Foundation

// Tuples and Sets

var dog : (String,Int) = ("Fido",8)

dog.1

var luckyNumbers : Set = [432,5,324,32,5,134,21,312]

luckyNumbers.insert(44)
luckyNumbers.contains(5)

// Create a set of Strings of your favorite food

var favFood : Set = ["Oreos","Pizza","Gyudon"]
favFood.insert("Oreos")
favFood

