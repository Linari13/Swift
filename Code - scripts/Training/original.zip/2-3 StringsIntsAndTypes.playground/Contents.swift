import Foundation

var age : Int = 30

let name : String = "Nick"

let time = 46

