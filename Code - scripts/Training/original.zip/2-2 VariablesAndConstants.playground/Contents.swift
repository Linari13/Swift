import Foundation

let age = 30

var name = "Nick"

var candy = "100 Grand"
